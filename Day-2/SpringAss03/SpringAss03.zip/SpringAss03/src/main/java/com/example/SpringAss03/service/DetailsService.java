package com.example.SpringAss03.service;

import com.example.SpringAss03.entity.DetailsInfo;

public interface DetailsService {

    public String add(DetailsInfo detailsInfo);
}
