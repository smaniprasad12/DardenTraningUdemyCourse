package com.example.SpringAss03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAss03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
